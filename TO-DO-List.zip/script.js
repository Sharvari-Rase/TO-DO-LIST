/* ============================================================
   TO-DO LIST APPLICATION - script.js
   Beginner-friendly JavaScript demonstrating arrays, objects,
   localStorage, DOM manipulation, functions, and event
   handling (including event delegation for dynamic buttons).
   ============================================================ */

/* ------------------------------------------------------------
   STEP 1: Grab references to all the HTML elements we need.
   ------------------------------------------------------------ */
const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const formMsg = document.getElementById("formMsg");

const taskList = document.getElementById("taskList");
const emptyState = document.getElementById("emptyState");
const summaryText = document.getElementById("summaryText");

/* ------------------------------------------------------------
   STEP 2: The key we use to store our tasks inside the
   browser's localStorage, and the main tasks ARRAY.
   Each task in this array is an OBJECT shaped like:
     { id: 1234, taskName: "Buy groceries", completed: false }
   ------------------------------------------------------------ */
const STORAGE_KEY = "todoTasks";
let tasks = [];

// Keeps track of which single task (by id) is currently being
// edited inline. null means "nothing is being edited right now".
// This is only used for rendering, so it is NOT saved to storage.
let editingTaskId = null;

/* ------------------------------------------------------------
   FUNCTION: saveToLocalStorage
   Converts the tasks array into a JSON string and stores it in
   localStorage so the list survives a page refresh.
   ------------------------------------------------------------ */
function saveToLocalStorage() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

/* ------------------------------------------------------------
   FUNCTION: loadFromLocalStorage
   Reads the saved JSON string (if any) back out of
   localStorage and turns it back into our tasks array.
   Runs once when the page first loads.
   ------------------------------------------------------------ */
function loadFromLocalStorage() {
  const savedData = localStorage.getItem(STORAGE_KEY);

  if (savedData) {
    tasks = JSON.parse(savedData);
  } else {
    tasks = []; // No saved tasks yet - start with an empty array
  }
}

/* ------------------------------------------------------------
   FUNCTION: addTask
   Reads the value from the input box, validates it, and (if
   valid) pushes a new task OBJECT onto the tasks ARRAY.
   ------------------------------------------------------------ */
function addTask() {
  const taskName = taskInput.value.trim();

  // Validation: do not allow empty tasks
  if (taskName === "") {
    formMsg.textContent = "Please type a task before adding it.";
    taskInput.classList.add("input-error");
    taskInput.focus();
    return;
  }

  // Clear any previous error state
  formMsg.textContent = "";
  taskInput.classList.remove("input-error");

  // Build the new task object. Date.now() gives us a unique
  // number every time, which works well as a simple ID.
  const newTask = {
    id: Date.now(),
    taskName: taskName,
    completed: false,
  };

  tasks.push(newTask); // Add the object to the array

  saveToLocalStorage(); // Keep localStorage in sync
  displayTasks();       // Re-draw the list on screen

  // Clear the input box and refocus it for the next task
  taskInput.value = "";
  taskInput.focus();
}

/* ------------------------------------------------------------
   FUNCTION: completeTask
   Finds the task with the matching id and flips its
   "completed" boolean between true and false.
   ------------------------------------------------------------ */
function completeTask(id) {
  // .find() searches the array and returns the matching object
  const task = tasks.find(function (t) {
    return t.id === id;
  });

  if (task) {
    task.completed = !task.completed;
    saveToLocalStorage();
    displayTasks();
  }
}

/* ------------------------------------------------------------
   FUNCTION: deleteTask
   Removes the task with the matching id from the tasks array
   using .filter(), which keeps everything EXCEPT that task.
   ------------------------------------------------------------ */
function deleteTask(id) {
  tasks = tasks.filter(function (t) {
    return t.id !== id;
  });

  saveToLocalStorage();
  displayTasks();
}

/* ------------------------------------------------------------
   FUNCTION: editTask
   Puts a task into "editing mode" so displayTasks() will draw
   an editable text box for it instead of plain text.
   ------------------------------------------------------------ */
function editTask(id) {
  editingTaskId = id;
  displayTasks();

  // After re-rendering, move focus into the new edit box
  const editInput = document.querySelector(".task-item__edit-input");
  if (editInput) {
    editInput.focus();
    editInput.select();
  }
}

/* ------------------------------------------------------------
   FUNCTION: saveEditedTask
   Called when the user confirms an edit. Validates the new
   text, updates the matching task object's taskName, and
   exits editing mode.
   ------------------------------------------------------------ */
function saveEditedTask(id, newName) {
  const trimmedName = newName.trim();

  // Don't allow saving an empty task name while editing
  if (trimmedName === "") {
    alert("Task name cannot be empty.");
    return;
  }

  const task = tasks.find(function (t) {
    return t.id === id;
  });

  if (task) {
    task.taskName = trimmedName;
  }

  editingTaskId = null; // Exit editing mode
  saveToLocalStorage();
  displayTasks();
}

/* ------------------------------------------------------------
   FUNCTION: cancelEdit
   Exits editing mode without saving any changes.
   ------------------------------------------------------------ */
function cancelEdit() {
  editingTaskId = null;
  displayTasks();
}

/* ------------------------------------------------------------
   FUNCTION: buildTaskItem
   Creates and returns a single <li> element for one task
   object. This keeps displayTasks() focused on looping, while
   this function focuses on building one row's HTML structure.
   ------------------------------------------------------------ */
function buildTaskItem(task) {
  const li = document.createElement("li");
  li.className = "task-item";
  if (task.completed) {
    li.classList.add("task-item--completed");
  }

  // ----- EDITING MODE: show a text input + Save/Cancel -----
  if (editingTaskId === task.id) {
    const editInput = document.createElement("input");
    editInput.type = "text";
    editInput.className = "task-item__edit-input";
    editInput.value = task.taskName;

    // Pressing Enter while editing saves the change
    editInput.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        saveEditedTask(task.id, editInput.value);
      }
    });

    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.className = "btn-sm btn-sm--complete";
    saveBtn.textContent = "Save";
    saveBtn.addEventListener("click", function () {
      saveEditedTask(task.id, editInput.value);
    });

    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.className = "btn-sm btn-sm--delete";
    cancelBtn.textContent = "Cancel";
    cancelBtn.addEventListener("click", cancelEdit);

    const actions = document.createElement("div");
    actions.className = "task-item__actions";
    actions.appendChild(saveBtn);
    actions.appendChild(cancelBtn);

    li.appendChild(editInput);
    li.appendChild(actions);
    return li;
  }

  // ----- NORMAL MODE: show the task name + action buttons -----
  const nameSpan = document.createElement("span");
  nameSpan.className = "task-item__name";
  nameSpan.textContent = task.taskName;

  const editBtn = document.createElement("button");
  editBtn.type = "button";
  editBtn.className = "btn-sm btn-sm--edit";
  editBtn.textContent = "Edit";
  editBtn.addEventListener("click", function () {
    editTask(task.id);
  });

  const completeBtn = document.createElement("button");
  completeBtn.type = "button";
  completeBtn.className = "btn-sm btn-sm--complete";
  completeBtn.textContent = task.completed ? "Undo" : "Complete";
  completeBtn.addEventListener("click", function () {
    completeTask(task.id);
  });

  const deleteBtn = document.createElement("button");
  deleteBtn.type = "button";
  deleteBtn.className = "btn-sm btn-sm--delete";
  deleteBtn.textContent = "Delete";
  deleteBtn.addEventListener("click", function () {
    deleteTask(task.id);
  });

  const actions = document.createElement("div");
  actions.className = "task-item__actions";
  actions.appendChild(editBtn);
  actions.appendChild(completeBtn);
  actions.appendChild(deleteBtn);

  li.appendChild(nameSpan);
  li.appendChild(actions);
  return li;
}

/* ------------------------------------------------------------
   FUNCTION: displayTasks
   The main rendering function. Clears the current <ul> and
   rebuilds it from scratch based on the tasks array. Also
   updates the empty-state message and the summary counter.
   ------------------------------------------------------------ */
function displayTasks() {
  // Clear out everything currently in the list
  taskList.innerHTML = "";

  // Build and insert one <li> per task in the array
  tasks.forEach(function (task) {
    const taskItem = buildTaskItem(task);
    taskList.appendChild(taskItem);
  });

  // Show the "empty list" message only when there are no tasks
  if (tasks.length === 0) {
    emptyState.classList.add("is-visible");
  } else {
    emptyState.classList.remove("is-visible");
  }

  // Update the small summary line, e.g. "2 of 5 tasks completed"
  const completedCount = tasks.filter(function (t) {
    return t.completed;
  }).length;

  if (tasks.length === 0) {
    summaryText.textContent = "No tasks yet";
  } else {
    summaryText.textContent = completedCount + " of " + tasks.length + " tasks completed";
  }
}

/* ------------------------------------------------------------
   STEP 3: Wire up the event listeners.
   ------------------------------------------------------------ */

// Add Task button
addTaskBtn.addEventListener("click", addTask);

// Also allow pressing Enter inside the input box to add a task
taskInput.addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    addTask();
  }
});

/* ------------------------------------------------------------
   STEP 4: On page load, restore any previously saved tasks
   and draw them on screen right away.
   ------------------------------------------------------------ */
loadFromLocalStorage();
displayTasks();
