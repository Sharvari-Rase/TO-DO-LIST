/* ============================================================
   DIGITAL STOPWATCH - script.js
   Beginner-friendly JavaScript demonstrating events, functions,
   timers (setInterval/clearInterval), and DOM manipulation.
   ============================================================ */

/* ------------------------------------------------------------
   STEP 1: Grab references to all the HTML elements we need.
   ------------------------------------------------------------ */
const minutesDisplay = document.getElementById("minutes");
const secondsDisplay = document.getElementById("seconds");
const millisecondsDisplay = document.getElementById("milliseconds");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const resetBtn = document.getElementById("resetBtn");

const displayBox = document.getElementById("display");
const statusBox = document.querySelector(".status");
const statusText = document.getElementById("statusText");

/* ------------------------------------------------------------
   STEP 2: Variables that hold the stopwatch's current state.
   - minutes / seconds / milliseconds : the time counted so far
   - intervalId : stores the ID returned by setInterval() so we
     can later stop it with clearInterval(). It starts as null,
     meaning "no timer is currently running".
   ------------------------------------------------------------ */
let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let intervalId = null;

// The stopwatch "ticks" every 10 milliseconds. This controls
// how smooth/precise the millisecond count looks on screen.
const TICK_INTERVAL_MS = 10;

/* ------------------------------------------------------------
   FUNCTION: padNumber
   Small helper that turns a number like 5 into the string "05"
   so the display always shows two digits.
   ------------------------------------------------------------ */
function padNumber(num) {
  return num < 10 ? "0" + num : String(num);
}

/* ------------------------------------------------------------
   FUNCTION: updateDisplay
   Reads the current minutes/seconds/milliseconds variables and
   writes them onto the page using DOM manipulation. This is the
   ONLY function that touches the on-screen time text.
   ------------------------------------------------------------ */
function updateDisplay() {
  minutesDisplay.textContent = padNumber(minutes);
  secondsDisplay.textContent = padNumber(seconds);

  // We tick every 10ms, so dividing by 10 gives a neat 2-digit
  // "centisecond" count (00-99) for the MS segment.
  millisecondsDisplay.textContent = padNumber(milliseconds / 10);
}

/* ------------------------------------------------------------
   FUNCTION: tick
   Runs every TICK_INTERVAL_MS while the stopwatch is running.
   Increases milliseconds, and "rolls over" into seconds and
   minutes once each unit reaches its limit (just like a
   real clock).
   ------------------------------------------------------------ */
function tick() {
  milliseconds += TICK_INTERVAL_MS;

  if (milliseconds >= 1000) {
    milliseconds = 0;
    seconds++;
  }

  if (seconds >= 60) {
    seconds = 0;
    minutes++;
  }

  updateDisplay();
}

/* ------------------------------------------------------------
   FUNCTION: startStopwatch
   Runs when the Start button is clicked.
   - If a timer is ALREADY running (intervalId is not null),
     we do nothing. This is what prevents multiple overlapping
     intervals from stacking up on repeated clicks.
   - Otherwise, we start a new interval with setInterval().
   ------------------------------------------------------------ */
function startStopwatch() {
  if (intervalId !== null) {
    return; // A timer is already running - ignore this click
  }

  intervalId = setInterval(tick, TICK_INTERVAL_MS);

  // Update the UI to show the "running" state
  statusBox.classList.add("status--running");
  displayBox.classList.add("display--running");
  statusText.textContent = "Running";

  // Disable Start so it can't be clicked again while running
  startBtn.disabled = true;
}

/* ------------------------------------------------------------
   FUNCTION: stopStopwatch
   Runs when the Stop button is clicked.
   Uses clearInterval() to pause the timer without resetting
   the time that has already been counted.
   ------------------------------------------------------------ */
function stopStopwatch() {
  clearInterval(intervalId);
  intervalId = null; // Mark that no timer is running anymore

  // Update the UI to show the "paused" state
  statusBox.classList.remove("status--running");
  displayBox.classList.remove("display--running");
  statusText.textContent = "Paused";

  // Re-enable Start so the stopwatch can be resumed
  startBtn.disabled = false;
}

/* ------------------------------------------------------------
   FUNCTION: resetStopwatch
   Runs when the Reset button is clicked.
   Stops any running timer and sets the time back to 00:00:00.
   ------------------------------------------------------------ */
function resetStopwatch() {
  clearInterval(intervalId);
  intervalId = null;

  // Reset all the time-tracking variables back to zero
  minutes = 0;
  seconds = 0;
  milliseconds = 0;
  updateDisplay();

  // Update the UI to show the "ready" state
  statusBox.classList.remove("status--running");
  displayBox.classList.remove("display--running");
  statusText.textContent = "Ready";

  startBtn.disabled = false;
}

/* ------------------------------------------------------------
   STEP 3: Wire up the event listeners so our functions above
   actually run when the user clicks each button.
   ------------------------------------------------------------ */
startBtn.addEventListener("click", startStopwatch);
stopBtn.addEventListener("click", stopStopwatch);
resetBtn.addEventListener("click", resetStopwatch);

/* ------------------------------------------------------------
   Show 00:00:00 as soon as the page loads.
   ------------------------------------------------------------ */
updateDisplay();
